# Nuevo formulario de Login

## Formulario de Login con nuevos estilos 


<!-- Add banner here -->
![Banner](https://raw.githubusercontent.com/jcgeneration/newLogin/main/img/newLogin.png)








