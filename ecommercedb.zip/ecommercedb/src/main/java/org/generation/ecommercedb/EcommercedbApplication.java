package org.generation.ecommercedb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommercedbApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommercedbApplication.class, args);
	}

}
